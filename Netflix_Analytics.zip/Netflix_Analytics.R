# load necessary libraries
library(ggplot2)
library(dplyr)

# Read the cleaned dataset
#df <- read.csv("Netflix_shows_movies.csv")
df<-read.csv(file.choose(),header=TRUE)

# Convert the date_added column to Date type
df$date_added <- as.Date(df$date_added, format="%B %d, %Y")


# Create the Distribution of Ratings chart

# Count the number of occurrences for each rating
rating_count <- df %>% 
  group_by(rating) %>% 
  summarise(count = n()) %>% 
  arrange(desc(count))

# Create the plot
ggplot(data=rating_count, aes(x=reorder(rating, -count), y=count)) +
  geom_bar(stat="identity", fill="steelblue") +
  theme_minimal() +
  labs(title="Distribution of Ratings", x="Rating", y="Count") +
  theme(axis.text.x = element_text(angle=45, hjust=1))

  
  